# File Directions to Edit the App 
SmartSole\app\src\main\java\com\example\smartsole\MainActivity.kt
